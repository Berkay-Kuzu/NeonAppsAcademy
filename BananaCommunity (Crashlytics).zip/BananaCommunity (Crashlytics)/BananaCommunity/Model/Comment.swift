//
//  Comment.swift
//  BananaCommunity
//
//  Created by Berkay Kuzu on 23.06.2023.
//

import Foundation

struct Comment{
    let userName: String
    let userComment: String
}
