//
//  Model.swift
//  SearchBar
//
//  Created by Berkay Kuzu on 9.06.2023.
//

import Foundation

struct NeonAcademyPerson {
    let name: String
    let surname: String
}
